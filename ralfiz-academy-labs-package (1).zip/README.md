# Ralfiz Academy Labs — content package

## What's here
- `ralfiz-academy-labs.html` — the complete working site as one file. Open it in a browser, or host it as a static page. It needs internet access only for Google Fonts and the JSZip library (used by "Download all (.zip)").
- `content/` — all course content as JSON, ready to import into your own platform:
  - `pl900.json`, `ab410.json`, `pl300.json`, `ab400.json`: track → skill areas → lessons. Each lesson has `summaryHtml`, `contentHtml` (the in-depth lesson), `terms`, `examTip`, `lab` (`files`, `steps`, `check`), `quiz` (`answer` is the 0-based index of the correct option), plus the optional `widget` and `sorter`. PL-300 also has a 40-question `questionBank`.
  - `files-index.json`: every exercise file id → its path and description.
- `exercise-files/` — every exercise file on disk:
  - `shared-data/hd/` Campus Help Desk datasets (tickets, categories, students, staff, feedback) used by PL-900, AB-410 and AB-400.
  - `shared-data/pbi/` Power BI datasets used by PL-300.
  - `<track>/<lesson>/` the lesson's own files (starter and solution code, specs, snippets) plus `LAB.md` with the steps and checklist.

## Notes for integration
- Lesson HTML uses only: h3, p, ul, ol, li, strong, em, code, pre.code, table, div.example, div.callout, div.callout.warn. The styles are in the `<style>` block of the HTML file.
- File ids in `lab.files` starting with `hd/` or `pbi/` point to `exercise-files/shared-data/`; others are `<track>/<lesson>/<path>`.
- The in-browser simulators (Power Fx console, Flow builder, DAX console, star schema builder, dataset panel, sorters) are plain JavaScript inside the HTML file. The widget name in each lesson tells you which one to mount.
- Content reflects Microsoft's study guides as of September 2026 (PL-900 24 Jul 2026, PL-300 20 Apr 2026, AB-410 26 Apr 2026, AB-400 outline effective 16 Oct 2026). Recheck before each exam update.
